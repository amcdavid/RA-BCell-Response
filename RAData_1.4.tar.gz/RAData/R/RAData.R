

#' RAData
#' A data package for study RAData
#' @docType package
#' @aliases RAData-package
#' @title RAData
#' @name RAData
#' @description a description of the package.
#' @details Additional details.
#' @import data.table
#' @import stringr
#' @import knitr
#' @seealso \link{mydataset}
NULL
NULL
